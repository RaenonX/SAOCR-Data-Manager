package com.beust.jcommander;

public class Strings {
  public static boolean isStringEmpty(String s) {
    return s == null || "".equals(s);
  }
}
